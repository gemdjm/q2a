var helpText="<br /><p><b>Q2A</b> asks questions and shows a number of possible answers</p>"
+ "<p>Tap 'Start' to start a session, a question will appear.</p>"
+ "<p>Tap an answer; if correct a new question appears.</p>"
+ "<br />"
;

var helpTextTemp="Q2A asks questions and shows a number of possible answers."
+ "\n\nTap 'Start' to start a session, a question will appear."
+ "\nTap an answer; if correct a new question appears."
;
